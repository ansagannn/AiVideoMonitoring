# AI-видеомониторинг MVP

Рабочий прототип MVP-системы AI-видеомониторинга для контроля присутствия сотрудников и базовой фиксации событий-кандидатов в торговой зоне.

## Что входит

- FastAPI backend с SQLite persistence для камер, событий, feedback и настроек.
- React + TypeScript dashboard с разделами: обзор, события, аналитика/отчёты, камеры, настройки.
- Public/open-source retail-like sources: CUHK Mall, MERL Shopping, RetailAction metadata.
- Demo/live camera preview SVG с bbox, зонами и overlay признаков.
- Кадр/snapshot к каждому событию с evidence tags и analysis summary.
- Feedback оператора: подтверждение/отклонение события.
- Telegram inline-preview с кнопками `Подтвердить` / `Отклонить` и безопасным mock-режимом без токенов.
- Аналитика смены/дня и экспорт отчёта CSV/PDF.
- Визуальные role badges: админ, оператор, руководитель.
- Backend также может отдавать production build frontend по тому же origin.
- Отдельный блок `Что уже умеем выявлять по ТЗ`: признаки, confidence, evidence, ограничения и mapping к этапам ТЗ.

## MVP-сценарии

1. Оператор открывает dashboard.
2. Видит public/demo камеры, live-preview, зоны, bbox overlay, статусы потоков и AI-обработки.
3. Видит capability matrix: что MVP уже выявляет, какие evidence использует и где нужны пилотные данные.
4. Видит ленту событий-кандидатов.
5. Фильтрует события по камере, типу, статусу и времени.
6. Нажимает `Симулировать событие`.
7. Видит snapshot события, evidence tags и Telegram inline-preview.
8. Подтверждает или отклоняет событие кнопками `Подтвердить` / `Отклонить`.
9. Руководитель открывает аналитику смены и скачивает CSV/PDF отчёт.
10. Админ меняет пороги отсутствия, нахождения у полки и confidence threshold.

## Структура

```text
ai-video-monitoring-mvp/
  backend/
    app/main.py
    pyproject.toml
  frontend/
    src/App.tsx
    src/App.css
    package.json
    .env
```

## Backend

### Локальный запуск

```bash
cd backend
poetry install
poetry run fastapi dev app/main.py --host 0.0.0.0 --port 8000
```

### API endpoints

| Метод | Endpoint | Назначение |
| --- | --- | --- |
| GET | `/healthz` | Healthcheck backend |
| GET | `/api/overview` | Метрики dashboard |
| GET | `/api/cameras` | Список камер и зон |
| GET | `/api/cameras/{camera_id}/live.svg` | Live-preview камеры с bbox/зонами |
| GET | `/api/public-sources` | Public/open-source источники, сценарии и license notes |
| GET | `/api/detection-capabilities` | Анализ возможностей детекции по ТЗ |
| GET | `/api/events` | Лента событий с фильтрами `camera_id`, `event_type`, `status`, `date_from`, `date_to` |
| POST | `/api/events/simulate` | Создание тестового события |
| POST | `/api/events/{event_id}/feedback` | Feedback оператора |
| GET | `/api/events/{event_id}/snapshot.svg` | Snapshot/кадр события |
| GET | `/api/shift/analytics` | Аналитика смены/дня |
| GET | `/api/settings` | Пороговые настройки |
| PUT | `/api/settings` | Обновление пороговых настроек |
| GET | `/api/telegram/preview` | Preview Telegram-сообщения с inline-кнопками |
| POST | `/api/telegram/test` | Проверка Telegram/mock уведомления |
| GET | `/api/reports/day.csv` | CSV отчёт за день |
| GET | `/api/reports/day.pdf` | PDF отчёт за день |

### Telegram

Для реальной отправки уведомлений задайте переменные окружения перед запуском backend:

```bash
export TELEGRAM_BOT_TOKEN="<bot-token>"
export TELEGRAM_CHAT_ID="<chat-id>"
poetry run fastapi dev app/main.py --host 0.0.0.0 --port 8000
```

Если переменные не заданы, Telegram работает в mock-режиме: API не падает, а dashboard показывает preview сообщения с inline-кнопками.

## Frontend

### Локальный запуск frontend отдельно

```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0 --port 5173
```

Для отдельного frontend dev server укажите backend URL в `frontend/.env`:

```env
VITE_API_URL=http://localhost:8000
```

### Production build

```bash
cd frontend
npm run lint
npm run build
```

После `npm run build` backend может отдавать frontend из `frontend/dist` по адресу `http://localhost:8000/`.

## Проверка

```bash
# backend
curl http://localhost:8000/healthz
curl http://localhost:8000/api/overview
curl -X POST http://localhost:8000/api/events/simulate \
  -H 'Content-Type: application/json' \
  -d '{"camera_id":"cam-sales-floor-1"}'

# frontend
cd frontend
npm run lint
npm run build
```

## Ограничения MVP

- Нет реальной обработки RTSP-потоков; используются public research/demo metadata, demo/live SVG preview и mock RTSP источники.
- Не используются сомнительные открытые live-камеры с реальными людьми без разрешения; выбран безопасный research/demo подход.
- Нет ML/CV модели; события создаются симулятором и демонстрируют будущий AI workflow.
- SQLite подходит для MVP/демо, для промышленного пилота лучше PostgreSQL.
- Детекция подозрительных действий в коммерческом предложении должна позиционироваться как события-кандидаты для проверки оператором, а не как юридическое доказательство кражи.
- Точность зависит от качества камер, угла обзора, расстояния до объектов и стабильности потоков.

## Что добавить на следующем этапе

- Подключение реальных RTSP-потоков или видеофайлов пилотной точки.
- Реальная CV-модель детекции людей и трекинг внутри зон.
- Реальные video snippets к событиям.
- Полная авторизация и RBAC вместо визуальных role badges.
- PostgreSQL + миграции для production/pilot.
- Накопление датасета подтверждённых/отклонённых событий для донастройки эвристик.
